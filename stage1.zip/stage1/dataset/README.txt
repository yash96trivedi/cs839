Entity Type: Person Names from BBC Entertainment Articles

Full Name: <f> </f>
Prefix: <p> </p>
Suffix: <s> </s>
Name: <n> </n>

Marked Up Documents: dataset (https://github.com/yash96trivedi/cs839/tree/master/stage1/dataset)

Marked Up Train: train (https://github.com/yash96trivedi/cs839/tree/master/stage1/train)

Marked Up Test: (test https://github.com/yash96trivedi/cs839/tree/master/stage1/test)